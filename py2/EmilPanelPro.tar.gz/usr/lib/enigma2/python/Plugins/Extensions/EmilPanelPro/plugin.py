#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import os
import socket
import time
import json
import hashlib
from subprocess import check_output

sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/EmilPanelPro')

from Screens.Console import Console
from enigma import getDesktop, ePoint, eListboxPythonMultiContent, gFont, loadPNG
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Components.Sources.Clock import Clock
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest

PLUGIN_VERSION = "2.0.0"
PLUGIN_DESC = "Enigma2 Tools"

plugin_path = resolveFilename(SCOPE_PLUGINS, "Extensions/EmilPanelPro")
IMG_DIR = os.path.join(plugin_path, "images")
IMG_DIR_HD = os.path.join(plugin_path, "images-hd")

def get_resolution():
    desktop_size = getDesktop(0).size()
    if desktop_size.width() >= 1920:
        return "FHD"
    else:
        return "HD"

def get_image_info():
    try:
        if os.path.exists("/etc/issue"):
            with open("/etc/issue", "r") as f:
                issue_content = f.read().strip().lower()
                if "openatv" in issue_content:
                    return "OpenATV"
                elif "openpli" in issue_content:
                    return "OpenPLi"
        return "Unknown"
    except Exception:
        return "Unknown"

def get_internet_status():
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except Exception:
        return False

def get_ip_address():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "No IP"

def load_image_safe(path):
    try:
        if os.path.exists(path):
            return loadPNG(path)
    except Exception:
        pass
    return None

def _grid_pixmaps(res):
    parts = []
    if res == "HD":
        xs = [40, 180, 320, 460, 600]
        ys = [80, 220, 360, 500]
        w, h = 100, 100
        lw, lh, fs, off = 100, 30, 20, 95
        limit = 20
    else:
        xs = [70, 280, 495, 705, 910]
        ys = [160, 370, 575, 775]
        w, h = 150, 150
        lw, lh, fs, off = 150, 50, 24, 160
        limit = 20
    idx = 1
    for y in ys:
        for x in xs:
            parts.append('<widget name="pixmap%s" position="%s,%s" size="%s,%s" zPosition="2" transparent="1" alphatest="blend" />' % (idx, x, y, w, h))
            parts.append('<widget name="name_label%s" position="%s,%s" size="%s,%s" font="Regular;%s" halign="center" valign="center" zPosition="2" transparent="1" foregroundColor="white" />' % (idx, x, y+off, lw, lh, fs))
            idx += 1
            if idx > limit:
                break
        if idx > limit:
            break
    return "\n    ".join(parts)

HD_SKIN = """
<screen position="center,center" size="1280,720" title="Emil Panel Pro">
    <ePixmap position="0,0" zPosition="0" size="1280,720" pixmap="%s/panel.png" transparent="1" alphatest="blend" />
    <eLabel position="0,0" zPosition="-10" size="1280,720" backgroundColor="black" />
    <eLabel cornerRadius="25" position="20,20" size="690,620" zPosition="1" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="22" position="23,23" size="684,614" zPosition="1" backgroundColor="#000000" transparent="0" />
    <widget name="frame" position="60,150" size="100,100" pixmap="%s/pic_frame2.png" zPosition="3" transparent="1" alphatest="blend" />
    %s
    <widget name="system_info" position="750,460" size="480,100" font="Regular;30" halign="center" valign="center" foregroundColor="#0049bbff" backgroundColor="transparent" transparent="0" zPosition="10" />
    <eLabel cornerRadius="18" position="60,670" size="150,30" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <widget name="key_red" position="60,655" size="150,60" valign="center" halign="center" zPosition="4" foregroundColor="white" font="Regular;26" transparent="1" text="Exit" />
    <eLabel cornerRadius="18" position="230,670" size="150,30" zPosition="3" backgroundColor="#347235" transparent="0" />
    <widget name="key_green" position="230,655" size="150,60" valign="center" halign="center" zPosition="4" foregroundColor="white" font="Regular;26" transparent="1" text="Ok" />
    <eLabel cornerRadius="18" position="400,670" size="150,30" zPosition="3" backgroundColor="#EAC117" transparent="0" />
    <widget name="key_yellow" position="400,655" size="150,60" valign="center" halign="center" zPosition="4" foregroundColor="white" font="Regular;26" transparent="1" text="Update" />
    <eLabel cornerRadius="18" position="570,670" size="150,30" zPosition="3" backgroundColor="#0049bbff" transparent="0" />
    <widget name="key_blue" position="570,655" size="150,60" valign="center" halign="center" zPosition="4" foregroundColor="white" font="Regular;26" transparent="1" text="Restart" />
    <eLabel cornerRadius="18" position="800,650" size="270,70" zPosition="3" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="805,655" size="260,60" zPosition="3" backgroundColor="#40000000" transparent="0" />
    <widget name="sort" position="850,656" zPosition="4" size="340,60" font="Regular; 28" foregroundColor="#0049bbff" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />
    <eLabel name="sort_index" position="810,666" size="30,30" backgroundColor="#0049bbff" halign="center" valign="center" transparent="0" cornerRadius="25" font="Regular; 32" zPosition="4" text="0" foregroundColor="white" />
    <eLabel cornerRadius="18" position="1100,640" size="170,70" zPosition="3" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="1105,645" size="160,60" zPosition="3" backgroundColor="#40000000" transparent="0" />
    <widget source="CurrentTime" render="Label" position="1110,646" size="150,60" font="Regular;36" halign="center" valign="center" foregroundColor="#0049bbff" backgroundColor="#40000000" transparent="1" zPosition="4">
        <convert type="ClockToText">Default</convert>
    </widget>
    <widget source="session.VideoPicture" render="Pig" position="750,120" size="480,320" zPosition="1" backgroundColor="#ff000000" />
    <ePixmap position="900,40" zPosition="2" size="200,100" pixmap="%s/emilpanel.png" alphatest="on" />
</screen>
"""

FHD_SKIN = """
<screen position="center,center" size="1920,1080" title="Emil Panel Pro">
    <ePixmap position="0,0" zPosition="0" size="1920,1080" pixmap="%s/panel.png" transparent="1" alphatest="blend" />
    <eLabel position="0,0" zPosition="-10" size="1920,1080" backgroundColor="black" />
    <eLabel cornerRadius="35" position="40,130" size="1030,850" zPosition="1" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="32" position="43,133" size="1024,844" zPosition="1" backgroundColor="#000000" transparent="0" />
    <widget name="frame" position="70,210" size="150,150" pixmap="%s/pic_frame2.png" zPosition="3" transparent="1" alphatest="blend" />
    %s
    <widget name="system_info" position="1100,760" size="600,140" font="Regular;42" halign="center" valign="center" foregroundColor="#0049bbff" backgroundColor="transparent" transparent="0" zPosition="10" />
    <eLabel cornerRadius="18" position="80,990" size="250,60" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <eLabel cornerRadius="18" position="85,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget name="key_red" position="80,995" size="250,60" valign="center" halign="center" zPosition="4" foregroundColor="#C11B17" backgroundColor="#000000" font="Regular;32" transparent="1" text="Exit" />
    <eLabel cornerRadius="18" position="340,990" size="250,60" zPosition="2" backgroundColor="#347235" transparent="0" />
    <eLabel cornerRadius="18" position="345,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget name="key_green" position="340,995" size="250,60" valign="center" halign="center" zPosition="4" foregroundColor="#347235" backgroundColor="#000000" font="Regular;32" transparent="1" text="Ok" />
    <eLabel cornerRadius="18" position="600,990" size="250,60" zPosition="2" backgroundColor="#EAC117" transparent="0" />
    <eLabel cornerRadius="18" position="605,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget name="key_yellow" position="600,995" size="250,60" valign="center" halign="center" zPosition="4" foregroundColor="#EAC117" backgroundColor="#000000" font="Regular;32" transparent="1" text="Update" />
    <eLabel cornerRadius="18" position="860,990" size="250,60" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="865,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0"/>
    <widget name="key_blue" position="860,995" size="250,60" valign="center" halign="center" zPosition="4" foregroundColor="#0049bbff" backgroundColor="#000000" font="Regular;32" transparent="1" text="Restart"/>
    <eLabel cornerRadius="18" position="1220,980" size="650,80" zPosition="3" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="1225,985" size="640,70" zPosition="3" backgroundColor="#40000000" transparent="0" />
    <widget name="sort" position="1300,986" zPosition="4" size="550,70" font="Regular; 42" foregroundColor="#0049bbff" backgroundColor="#40000000" transparent="1" halign="left" valign="center" />
    <eLabel name="sort_index" position="1235,1000" size="40,40" backgroundColor="#0049bbff" halign="center" valign="center" transparent="0" cornerRadius="35" font="Regular; 48" zPosition="4" text="0" foregroundColor="white" />
    <eLabel cornerRadius="18" position="1580,980" size="320,80" zPosition="3" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="1585,985" size="310,70" zPosition="3" backgroundColor="#40000000" transparent="0" />
    <widget source="CurrentTime" render="Label" position="1590,986" size="300,70" font="Regular;48" halign="center" valign="center" foregroundColor="#0049bbff" backgroundColor="#40000000" transparent="1" zPosition="4">
        <convert type="ClockToText">Default</convert>
    </widget>
    <widget source="session.VideoPicture" render="Pig" position="1100,180" size="750,550" zPosition="4" backgroundColor="#ff000000" />
    <eLabel cornerRadius="18" position="1095,175" size="760,560" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <ePixmap position="1250,40" zPosition="2" size="400,100" pixmap="%s/emilpanel.png" alphatest="on" />
</screen>
"""

HD_SKIN_LIST = """
<screen position="center,center" size="1280,720" title="%s">
    <ePixmap position="0,0" size="1280,720" pixmap="%s/back.png" zPosition="-1" />
    <widget source="title" render="Label" position="50,90" size="700,60"
        font="Regular;50" halign="center" valign="center"
        foregroundColor="#ffffff" backgroundColor="#000000" />
    <widget name="list" position="50,180" size="650,400" scrollbarMode="showOnDemand" backgroundColor="#000000" transparent="0" />
    <widget source="key_red" render="Label"
        position="80,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#C11B17" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="80,600" size="250,60" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <eLabel cornerRadius="18" position="85,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_green" render="Label"
        position="340,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#347235" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="340,600" size="250,60" zPosition="2" backgroundColor="#347235" transparent="0" />
    <eLabel cornerRadius="18" position="345,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_yellow" render="Label"
        position="600,600" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#EAC117" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="600,600" size="250,60" zPosition="2" backgroundColor="#EAC117" transparent="0" />
    <eLabel cornerRadius="18" position="605,605" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_blue" render="Label"
        position="860,600" size="400,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#0049bbff" backgroundColor="#000000"
        font="Regular;32" transparent="1" />
    <eLabel cornerRadius="18" position="860,600" size="400,60" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="865,605" size="390,50" zPosition="3" backgroundColor="#000000" transparent="0"/>
    <widget source="session.VideoPicture" render="Pig" position="750,120" size="480,320" zPosition="1" backgroundColor="#ff000000" />
    <ePixmap position="900,20" zPosition="2" size="200,100" pixmap="%s/emilpanel.png" alphatest="on" />
    <widget source="CurrentTime" render="Label" position="1100,666" size="250,50" font="Regular;32" halign="left" valign="center" foregroundColor="#0049bbff" backgroundColor="#20000000" transparent="1" zPosition="2">
        <convert type="ClockToText">Default</convert>
    </widget>
</screen>
"""

FHD_SKIN_LIST = """
<screen position="center,center" size="1920,1080" title="%s">
    <ePixmap position="0,0" size="1920,1080" pixmap="%s/back.png" zPosition="-1" />
    <widget source="title" render="Label" position="50,90" size="700,60"
        font="Regular;50" halign="center" valign="center"
        foregroundColor="#ffffff" backgroundColor="#000000" />
    <widget name="list" position="50,180" size="1000,565" scrollbarMode="showOnDemand" backgroundColor="#000000" transparent="0" />
    <widget source="key_red" render="Label"
        position="80,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#C11B17" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="80,990" size="250,60" zPosition="3" backgroundColor="#C11B17" transparent="0" />
    <eLabel cornerRadius="18" position="85,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_green" render="Label"
        position="340,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#347235" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="340,990" size="250,60" zPosition="2" backgroundColor="#347235" transparent="0" />
    <eLabel cornerRadius="18" position="345,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_yellow" render="Label"
        position="600,995" size="250,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#EAC117" backgroundColor="#000000"
        font="Regular;32" transparent="1"/>
    <eLabel cornerRadius="18" position="600,990" size="250,60" zPosition="2" backgroundColor="#EAC117" transparent="0" />
    <eLabel cornerRadius="18" position="605,995" size="240,50" zPosition="3" backgroundColor="#000000" transparent="0" />
    <widget source="key_blue" render="Label"
        position="860,995" size="650,60" valign="center" halign="center"
        zPosition="4" foregroundColor="#0049bbff" backgroundColor="#000000"
        font="Regular;32" transparent="1" />
    <eLabel cornerRadius="18" position="860,990" size="650,60" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <eLabel cornerRadius="18" position="865,995" size="640,50" zPosition="3" backgroundColor="#000000" transparent="0"/>
    <widget source="session.VideoPicture" render="Pig" position="1100,180" size="750,550" zPosition="4" backgroundColor="#ff000000" />
    <eLabel cornerRadius="18" position="1095,175" size="760,560" zPosition="2" backgroundColor="#0049bbff" transparent="0" />
    <ePixmap position="1250,40" zPosition="2" size="400,100" pixmap="%s/emilpanel.png" alphatest="on" />
    <widget source="CurrentTime" render="Label" position="1650,986" size="350,60" font="Regular;36" halign="left" valign="center" foregroundColor="#0049bbff" backgroundColor="#20000000" transparent="1" zPosition="2">
        <convert type="ClockToText">Default</convert>
    </widget>
</screen>
"""

class CheckList(MenuList):
    def __init__(self, lst, enableWrapAround=True):
        MenuList.__init__(self, lst, enableWrapAround, eListboxPythonMultiContent)
        if get_resolution() == "FHD":
            self.l.setItemHeight(56)
            self.l.setFont(0, gFont("Regular", 40))
        else:
            self.l.setItemHeight(40)
            self.l.setFont(0, gFont("Regular", 22))

class EmilPanelProScreen(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        res2 = get_resolution()
        grid = _grid_pixmaps(res2)
        if res2 == "FHD":
            self.skin = FHD_SKIN % (IMG_DIR, IMG_DIR, grid, IMG_DIR)
        else:
            self.skin = HD_SKIN % (IMG_DIR_HD, IMG_DIR_HD, grid, IMG_DIR_HD)

        self.entries = [
            ("Panels", "panels", "panels.png"),
            ("Plugins", "plugins", "plugins.png"),
            ("Channels", "channels", "channels.png"),
            ("Feeds", "feeds", "feeds.png"),
            ("Tools", "tools", "tools.png"),
            ("System", "system", "system.png"),
            ("Media", "media", "media.png"),
            ("Multiboot", "multiboot", "multiboot.png"),
            ("Softcams", "softcams", "emu.png"),
            ("Backup", "backup", "backup.png"),
            ("Restore", "restore", "backup.png"),
            ("Skins", "skins", "skins.png"),
            ("Remove", "remove", "remove.png"),
            ("Images", "images", "images.png"),
            ("Picons", "picons", "picon.png"),
            ("Bootlogos", "bootlogos", "bootlogo.png"),
        ]

        self.selected_index = 0
        self.sort_index = 0

        self["frame"] = Pixmap()
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Ok")
        self["key_yellow"] = Label("Update")
        self["key_blue"] = Label("Restart")
        self["sort"] = Label("Sort: Name A-Z")
        self["sort_index"] = Label("0")
        self["CurrentTime"] = Clock()
        self["system_info"] = Label("")

        for i in range(1, 21):
            self["pixmap" + str(i)] = Pixmap()
            self["name_label" + str(i)] = Label("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "NumberActions"],
            {
                "ok": self.okPressed,
                "cancel": self.close,
                "red": self.close,
                "green": self.okPressed,
                "yellow": self.updatePlugin,
                "blue": self.restartDevice,
                "up": self.upPressed,
                "down": self.downPressed,
                "left": self.leftPressed,
                "right": self.rightPressed,
                "0": self.toggleSort
            }, -1)

        self.onLayoutFinish.append(self.updateDisplay)

    def update_system_info(self):
        try:
            python_version = sys.version.split()[0]
            image_info = get_image_info()
            internet_status = get_internet_status()
            ip_address = get_ip_address()
            
            internet_text = "Online" if internet_status else "Offline"
            
            system_info = "Python: %s | Image: %s | Internet: %s | IP: %s" % (python_version, image_info, internet_text, ip_address)
            self["system_info"].setText(system_info)
            
        except Exception as e:
            self["system_info"].setText("System information unavailable")

    def updateDisplay(self):
        try:
            self.update_system_info()
        except Exception as e:
            print("Error in update_system_info:", str(e))
        
        items = self.entries
        base_img_dir = IMG_DIR_HD if get_resolution() == "HD" else IMG_DIR
        
        for i in range(min(20, len(items))):
            name, _, icon = items[i]
            ic = icon or "default.png"
            
            image_found = False
            possible_paths = [
                os.path.join(base_img_dir, ic),
                os.path.join(IMG_DIR, ic),
                os.path.join(IMG_DIR_HD, ic),
                os.path.join(plugin_path, ic)
            ]
            
            selected_path = None
            for img_path in possible_paths:
                try:
                    if os.path.exists(img_path):
                        selected_path = img_path
                        break
                except Exception:
                    continue
            
            if selected_path:
                try:
                    self["pixmap" + str(i+1)].instance.setPixmapFromFile(selected_path)
                    self["pixmap" + str(i+1)].show()
                    image_found = True
                except Exception:
                    image_found = False
            
            if not image_found:
                self["pixmap" + str(i+1)].hide()

            try:
                self["name_label" + str(i+1)].setText(name)
                self["name_label" + str(i+1)].show()
            except Exception:
                self["name_label" + str(i+1)].hide()

        for i in range(len(items), 20):
            self["pixmap" + str(i+1)].hide()
            self["name_label" + str(i+1)].hide()

        self.moveFrame(self.selected_index)
        self["sort_index"].setText(str(self.sort_index))

    def moveFrame(self, index):
        xs, ys = self._xy_sets()
        row = index // len(xs)
        col = index % len(xs)
        if row < len(ys) and col < len(xs):
            try:
                self["frame"].instance.move(ePoint(xs[col], ys[row]))
                self["frame"].show()
            except Exception:
                pass
        else:
            self["frame"].hide()

    def okPressed(self):
        if self.selected_index >= len(self.entries):
            return
        try:
            target = self.entries[self.selected_index][1]
            self._open_section_by_key(str(target))
        except Exception as e:
            self.session.open(MessageBox, "Error: %s" % str(e), MessageBox.TYPE_ERROR)

    def upPressed(self):
        if self.selected_index >= 5:
            self.selected_index -= 5
            self.moveFrame(self.selected_index)

    def downPressed(self):
        if self.selected_index + 5 < len(self.entries):
            self.selected_index += 5
            self.moveFrame(self.selected_index)

    def leftPressed(self):
        row = self.selected_index // 5
        col = self.selected_index % 5
        if col > 0:
            self.selected_index -= 1
        elif row > 0:
            target = (row - 1) * 5 + 4
            self.selected_index = min(target, len(self.entries) - 1)
        self.moveFrame(self.selected_index)

    def rightPressed(self):
        row = self.selected_index // 5
        col = self.selected_index % 5
        if (col < 4) and (self.selected_index + 1 < len(self.entries)):
            self.selected_index += 1
        else:
            next_row_start = (row + 1) * 5
            if next_row_start < len(self.entries):
                self.selected_index = next_row_start
        self.moveFrame(self.selected_index)

    def toggleSort(self):
        methods = ["Default", "Name A-Z", "Name Z-A"]
        cur = self["sort"].getText().replace("Sort: ", "")
        try:
            idx = (methods.index(cur) + 1) % len(methods)
        except Exception:
            idx = 0
        method = methods[idx]
        self["sort"].setText("Sort: " + method)
        self.sort_index = idx
        
        if method == "Default":
            self.entries = [
                ("Panels", "panels", "panels.png"),
                ("Plugins", "plugins", "plugins.png"),
                ("Channels", "channels", "channels.png"),
                ("Feeds", "feeds", "feeds.png"),
                ("Tools", "tools", "tools.png"),
                ("System", "system", "system.png"),
                ("Media", "media", "media.png"),
                ("Multiboot", "multiboot", "multiboot.png"),
                ("Softcams", "softcams", "emu.png"),
                ("Backup", "backup", "backup.png"),
                ("Restore", "restore", "backup.png"),
                ("Skins", "skins", "skins.png"),
                ("Remove", "remove", "remove.png"),
                ("Images", "images", "images.png"),
                ("Picons", "picons", "picon.png"),
                ("Bootlogos", "bootlogos", "bootlogo.png"),
            ]
        elif method == "Name A-Z":
            self.entries = sorted(self.entries, key=lambda x: x[0].lower())
        elif method == "Name Z-A":
            self.entries = sorted(self.entries, key=lambda x: x[0].lower(), reverse=True)
        
        self.selected_index = 0
        self.updateDisplay()

    def updatePlugin(self):
        update_script = "https://github.com/emilnabil/download-plugins/raw/refs/heads/main/EmilPanelPro/emilpanelpro.sh"
        self.session.open(
            Console, 
            "Updating EmilPanelPro", 
            ["wget %s -O - | /bin/sh" % update_script]
        )

    def restartDevice(self):
        self.session.open(TryQuitMainloop, 3)

    def _xy_sets(self):
        if get_resolution() == "FHD":
            return [70, 280, 495, 705, 910], [160, 370, 575, 775]
        return [40, 180, 320, 460, 600], [80, 220, 360, 500]

    def _open_section_by_key(self, key):
        title_map = {
            "panels": "Panels Manager",
            "plugins": "Plugins Manager",
            "channels": "Channels Manager",
            "feeds": "Feeds Manager",
            "tools": "Tools Manager",
            "system": "System Plugins",
            "media": "Media Manager",
            "multiboot": "Multiboot Manager",
            "softcams": "Softcams Manager",
            "backup": "Backup Manager",
            "restore": "Restore Manager",
            "skins": "Skins Manager",
            "images": "Images Manager",
            "picons": "Picons Manager",
            "remove": "Remove Manager",
            "bootlogos": "Bootlogos Manager",
        }
        
        title = title_map.get(key, "%s Manager" % key.title())
        
        green = "Install"
        if key == "backup":   green = "Backup"
        elif key == "restore": green = "Restore"
        elif key == "remove":  green = "Remove"
        
        if key in ["channels", "skins"]:
            self.session.open(ChannelsSubMenuScreen, title, key)
        else:
            self.session.open(JsonListScreen, title, key, green_label=green)

class ChannelsSubMenuScreen(Screen):
    def __init__(self, session, title, section_key):
        Screen.__init__(self, session)
        self.title = title
        self.section_key = section_key
        
        res2 = get_resolution()
        if res2 == "FHD":
            self.skin = FHD_SKIN_LIST % (self.title, IMG_DIR, IMG_DIR)
        else:
            self.skin = HD_SKIN_LIST % (self.title, IMG_DIR_HD, IMG_DIR_HD)

        self["title"] = StaticText(self.title)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText("Select")
        self["key_yellow"] = StaticText("Refresh")
        self["key_blue"] = StaticText("Restart GUI")
        self["CurrentTime"] = Clock()

        self["list"] = CheckList([], enableWrapAround=True)
        
        self._png_on = load_image_safe(os.path.join(IMG_DIR, "menug.png"))
        self._png_off = load_image_safe(os.path.join(IMG_DIR, "menug.png"))

        self._items = []
        self.onLayoutFinish.append(self._load_and_fill)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.okPressed,
            "cancel": self.close,
            "red": self.close,
            "green": self.okPressed,
            "yellow": self.doRefresh,
            "blue": self.restartEnigma2,
        }, -1)

    def _build_row(self, it):
        name = it.get("title", it.get("name", ""))
        name_b = name

        row = [ it ]
        if self._png_on and self._png_off:
            row.append(MultiContentEntryPixmapAlphaTest(
                pos=(10, 6), size=(44, 44),
                png=self._png_off
            ))
            text_x = 64
        else:
            name_b = "[ ] " + name_b
            text_x = 16

        row.append(MultiContentEntryText(
            pos=(text_x, 0), size=(620, 56), font=0, text=name_b
        ))
        return row

    def _repaint(self):
        self["list"].l.setList([ self._build_row(x) for x in self._items ])

    def _load_and_fill(self):
        if self.section_key == "channels":
            self._items = [
                {"title": "Other", "section": "other_channels", "icon": "channels.png"},
                {"title": "Ciefp", "section": "ciefp_channels", "icon": "ciefp.png"},
                {"title": "morph883", "section": "morph883_channels", "icon": "morpheus883.png"},
                {"title": "vaninbal", "section": "vaninbal_channels", "icon": "vhannibal.png"},
            ]
        elif self.section_key == "skins":
            self._items = [
                {"title": "OpenATV", "section": "openatv_skins", "icon": "openatv_icon.png"},
                {"title": "TeamNitro", "section": "TeamNitro_skins", "icon": "teamnitro.png"},
                {"title": "OpenBH", "section": "OpenBH_skins", "icon": "openbh_icon.png"},
                {"title": "Egami", "section": "Egami_skins", "icon": "egami_icon.png"},
                {"title": "OpenPli_py3", "section": "OpenPli_py3_skins", "icon": "openpli.png"},
                {"title": "OpenSpa", "section": "OpenSpa_skins", "icon": "openspa.png"},
                {"title": "OpenVix", "section": "OpenVix_skins", "icon": "openvix.png"},
                {"title": "OpenPli_py2", "section": "OpenPli_py2_skins", "icon": "openpli.png"},
                {"title": "Skins-Plugin-Xtreamity", "section": "PluginXtreamity_skins", "icon": "xstreamity.png"},
            ]
        self._repaint()

    def _current_index(self):
        try:
            return self["list"].getSelectedIndex()
        except Exception:
            return -1

    def okPressed(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self._items):
            return
            
        item = self._items[idx]
        section_key = item.get("section")
        title = item.get("title")
        
        if section_key:
            self.session.open(JsonListScreen, title, section_key, green_label="Install")

    def doRefresh(self):
        self._load_and_fill()
        self.session.open(MessageBox, "List refreshed.", MessageBox.TYPE_INFO, timeout=2)

    def restartEnigma2(self):
        restart_commands = [
            "systemctl restart enigma2",
            "killall -9 enigma2"
        ]
        self.session.open(
            Console, 
            "Restarting Enigma2", 
            restart_commands
        )

class JsonListScreen(Screen):
    def __init__(self, session, title, section_key, green_label=None):
        Screen.__init__(self, session)
        self.title = title
        self.section_key = section_key
        self.green_label_base = green_label or "Install"

        res2 = get_resolution()
        if res2 == "FHD":
            self.skin = FHD_SKIN_LIST % (self.title, IMG_DIR, IMG_DIR)
        else:
            self.skin = HD_SKIN_LIST % (self.title, IMG_DIR_HD, IMG_DIR_HD)

        self["title"] = StaticText(self.title)
        self["key_red"] = StaticText("Back")
        self["key_green"] = StaticText(self.green_label_base)
        self["key_yellow"] = StaticText("Refresh")
        self["key_blue"] = StaticText("Restart GUI")
        self["CurrentTime"] = Clock()

        self["list"] = CheckList([], enableWrapAround=True)

        self._png_on = load_image_safe(os.path.join(IMG_DIR, "toggle_on_green.png"))
        self._png_off = load_image_safe(os.path.join(IMG_DIR, "toggle_off.png"))

        self._items = []
        self.onLayoutFinish.append(self._load_and_fill)

        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "NumberActions"], {
            "ok": self.toggle_current,
            "cancel": self.close,
            "red": self.close,
            "green": self.install_selected,
            "yellow": self.doRefresh,
            "blue": self.restartEnigma2,
            "0": self.toggle_select_all
        }, -1)

    def _build_row(self, it):
        raw_name = it.get("name", "")
        installed = it.get("installed")
        
        name_b = raw_name
        
        if installed:
            name_b = name_b + " (installed)"

        row = [ it ]
        show_green = bool(it.get("selected")) or bool(installed)
        if self._png_on and self._png_off:
            row.append(MultiContentEntryPixmapAlphaTest(
                pos=(10, 6), size=(44, 44),
                png=self._png_on if show_green else self._png_off
            ))
            text_x = 64
        else:
            prefix = "[*] " if show_green else "[ ] "
            name_b = prefix + name_b
            text_x = 16

        row.append(MultiContentEntryText(
            pos=(text_x, 0), size=(620, 56), font=0, text=name_b
        ))
        return row

    def _repaint(self):
        self["list"].l.setList([ self._build_row(x) for x in self._items ])

    def _update_green_label(self):
        n = sum(1 for x in self._items if x.get("selected"))
        lbl = "%s (%d)" % (self.green_label_base, n) if n else self.green_label_base
        self["key_green"].setText(lbl)

    def _load_and_fill(self):
        try:
            data = []
            if self.section_key == "panels":
                data = [
                    ("Ajpanel", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/ajpanel/installer1.sh | sh"),
                    ("AjPanel Custom Menu All Panels", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ajpanel/emil-panel-all.sh | sh"),
                    ("Panel Lite By Emil Nabil", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ajpanel/new/emil-panel-lite.sh | sh"),
                    ("Ciefp-Panel", "wget -qO- https://github.com/ciefp/CiefpsettingsPanel/raw/main/installer.sh | sh"),
                    ("Ciefp-Panel mod Emil Nabil", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/Ciefp-Panel/Ciefp-Panel.sh | sh"),
                    ("dreamosat-downloader", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/dreamosat-downloader/installer.sh | sh"),
                    ("EmilPanel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/emilpanelpro/emilpanelpro.sh | sh"),
                    ("EmilPanelpro", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/EmilPanelPro/emilpanelpro.sh | sh"),
                    ("EliesatPanel", "wget -qO- https://raw.githubusercontent.com/eliesat/eliesatpanel/main/installer.sh | sh"),
                    ("Epanel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/epanel/installer.sh | sh"),
                    ("linuxsat-panel", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/LinuxsatPanel/main/installer.sh | sh"),
                    ("levi45emulator", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/levi45emulator/installer.sh | sh"),
                    ("levi45-AddonsManager", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/levi45-addonsmanager/installer.sh | sh"),
                    ("Levi45MulticamManager", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/levi45multicammanager/installer.sh | sh"),
                    ("MagicPanel-HAMDY_AHMED", "wget -qO- https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel_install.sh | sh"),
                    ("SatVenusPanel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/satvenuspanel/installer.sh | sh"),
                    ("Tspanel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/tspanel/installer.sh | sh"),
                    ("SmartAddonspanel", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/SmartAddonspanel/smart-Panel.sh | sh"),
                    ("TvAddon-Panel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/tvaddon/installer.sh | sh")
                ]
            elif self.section_key == "plugins":
                data = [
                    ("ArabicSavior", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/ArabicSavior/installer.sh | sh"),
                    ("Acherone", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/acherone/installer.sh | sh"),
                    ("AdvancedBootLogoSwapper", "wget -qO- https://raw.githubusercontent.com/popking159/abls/main/installer.sh | sh"),
                    ("Advanced-Screen-Shot", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/advancedscreenshot/advancedscreenshot.sh | sh"),
                    ("Alajre", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/alajre/installer.sh | sh"),
                    ("Ansite", "wget -qO- https://raw.githubusercontent.com/emil237/ansite/main/installer.sh | sh"),
                    ("Apod", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/apod/installer.sh | sh"),
                    ("Apsattv", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/Apsattv/main/installer.sh | sh"),
                    ("Astronomy", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/astronomy/installer.sh | sh"),
                    ("Athan Times", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/athantimes/installer.sh | sh"),
                    ("Atilehd", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/atilehd/installer.sh | sh"),
                    ("automatic-fullbackup", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/automatic-fullbackup/installer.sh | sh"),
                    ("Auto-Dcw-Key-Add", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/auto-dcw-key-add/auto-dcw-key-add.sh | sh"),
                    ("Azkar Almuslim", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/azkar-almuslim/installer.sh | sh"),
                    ("BissFeedAutoKey", "wget -qO- https://raw.githubusercontent.com/emilnabil/bissfeed-autokey/main/installer.sh | sh"),
                    ("Bitrate", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/bitrate/bitrate.sh | sh"),
                    ("Bitrate-mod-ariad", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/bitrate/bitrate-mod-ariad.sh | sh"),
                    ("Bundesliga-Permanent-Clock", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/bundesliga-permanent-clock/bundesliga-permanent-clock.sh | sh"),
                    ("CacheFlush", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/cacheflush/cacheflush.sh | sh"),
                    ("CCcaminfo-py2", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/cccaminfo/cccaminfo_py2.sh | sh"),
                    ("CCcaminfo-py3", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/cccaminfo/cccaminfo_py3.sh | sh"),
                    ("CrondManager", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/crondmanager/installer.sh | sh"),
                    ("CFG_ZOOM_FINAL", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/cfg_Zoom_Final_FIX7x/installer.sh | sh"),
                    ("CiefpBouquetUpdater", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpBouquetUpdater/main/installer.sh | sh"),
                    ("CiefpChannelManager", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpChannelManager/main/installer.sh | sh"),
                    ("CiefpE2Converter", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpE2Converter/main/installer.sh | sh"),
                    ("CiefpEPGshare", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpEPGshare/main/installer.sh | sh"),
                    ("CiefpIPTVBouquets", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpIPTVBouquets/main/installer.sh | sh"),
                    ("CiefpMojTvEPG", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpMojTvEPG/main/installer.sh | sh"),
                    ("CiefpOscamEditor", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpOscamEditor/main/installer.sh | sh"),
                    ("CiefpPlugins", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpPlugins/main/installer.sh | sh"),
                    ("CiefpSatelliteAnalyzer", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSatelliteAnalyzer/main/installer.sh | sh"),
                    ("CiefpSatellitesXmlEditor", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSatelliteXmlEditor/main/installer.sh | sh"),
                    ("CiefpScreenGrab", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpScreenGrab/main/installer.sh | sh"),
                    ("CiefpSelectSatellite", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSelectSatellite/main/installer.sh | sh"),
                    ("CiefpSettingsDownloader", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSettingsDownloader/main/installer.sh | sh"),
                    ("CiefpSettingsPanel", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpsettingsPanel/main/installer.sh | sh"),
                    ("CiefpSettingsStreamrelay PY2", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSettingsStreamrelayPY2/main/installer.sh | sh"),
                    ("CiefpSettingsStreamrelay PY3", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSettingsStreamrelay/main/installer.sh | sh"),
                    ("CiefpSettingsT2miAbertis", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertis/main/installer.sh | sh"),
                    ("CiefpSettingsT2miAbertisOpenPLi", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpSettingsT2miAbertisOpenPLi/main/installer.sh | sh"),
                    ("CiefpsettingsMotor", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpsettingsMotor/main/installer.sh | sh"),
                    ("CiefpTvProgram", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpTvProgram/main/installer.sh | sh"),
                    ("CiefpTvProgramA1HR", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpTvProgramA1HR/main/installer.sh | sh"),
                    ("CiefpTvProgramSBB", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpTvProgramSBB/main/installer.sh | sh"),
                    ("CiefpTvProgramSK", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpTvProgramSK/main/installer.sh | sh"),
                    ("CiefpTvTodayDE", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpTvTodayDE/main/installer.sh | sh"),
                    ("CiefpWhitelistStreamrelay", "wget -qO- https://raw.githubusercontent.com/ciefp/CiefpWhitelistStreamrelay/main/installer.sh | sh"),
                    ("chocholousek-picons", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/chocholousek-picons.sh | sh"),
                    ("CHLogoChanger", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/CHLogoChanger/ChLogoChanger.sh | sh"),
                    ("CrashLogoViewer", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/crashlogviewer/install-CrashLogViewer.sh | sh"),
                    ("CrondManger", "wget -qO- https://github.com/emil237/download-plugins/raw/main/cronmanager.sh | sh"),
                    ("Ddrss Reader", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/DDRSSReader/main/installer.sh | sh"),
                    ("Easy-Cccam", "wget -qO- https://raw.githubusercontent.com/emil237/plugins/main/easy-cccam/easy-cccam.sh | sh"),
                    ("enigma2readeradder", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/enigma2readeradder.sh | sh"),
                    ("Epg Grabber", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/Epg-Grabber/installer.sh | sh"),
                    ("EPGImport", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/epgimport.sh | sh"),
                    ("EPGImport-99", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/EPGImport-99/main/installer.sh | sh"),
                    ("EPGTranslator", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/epgtranslator.sh | sh"),
                    ("EvgQuickSignal", "wget -qO- https://raw.githubusercontent.com/biko-73/EvgQuickSignal/main/installer.sh | sh"),
                    ("Estalker", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/EStalker/EStalker.sh | sh"),
                    ("EstalkerWebControl", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/EstalkerWebControl/estalkerwebcontrol.sh | sh"),
                    ("Feeds-Finder", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/feeds-finder/installer.sh | sh"),
                    ("Filmxy", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/filmxy/filmxy.sh | sh"),
                    ("Footonsat", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/FootOnsat/installer.sh | sh"),
                    ("Freearhey", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/freearhey/freearhey.sh | sh"),
                    ("FreeCCcamServer", "wget -qO- https://ia903104.us.archive.org/0/items/freecccamserver/installer.sh | sh"),
                    ("gioppygio", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/gioppygio/gioppygio.sh | sh"),
                    ("hardwareinfo", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/hardwareinfo/installer.sh | sh"),
                    ("HasBahCa", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/HasBahCa/installer.sh | sh"),
                    ("HistoryZapSelector", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/historyzap/installer1.sh | sh"),
                    ("horoscope", "wget -qO- https://raw.githubusercontent.com/emilnabil/horoscope/main/horoscope.sh | sh"),
                    ("HolidayCountdown", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/HolidayCountdown/installer.sh | sh"),
                    ("Internet-Speedtest", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/internet-speedtest.sh | sh"),
                    ("IP_Checker", "wget -qO- https://raw.githubusercontent.com/emil237/plugins/main/IP_Checker.sh | sh"),
                    ("Iptv-Org-Playlists", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/iptv-org-playlists/iptv-org-playlists.sh | sh"),
                    ("iptvdream", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/iptvdream/iptvdream.sh | sh"),
                    ("IptvPlayer", "wget -qO- https://raw.githubusercontent.com/emil237/iptvplayer/main/iptvinstaller.sh | sh"),
                    ("KeyAdder", "wget -qO- https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh | sh"),
                    ("levi45-freeserver", "wget -qO- https://raw.githubusercontent.com/emil237/plugins/main/levi45-freeserver/levi45-freeserver.sh | sh"),
                    ("levi45-settings", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/levi45-settings/levi45-settings.sh | sh"),
                    ("M3uConverter", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/Archimede-M3UConverter/main/installer.sh | sh"),
                    ("MmPicons", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/mmPicons/main/installer.sh | sh"),
                    ("MoviesManager", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/Transmission/MoviesManager.sh | sh"),
                    ("MyCam-Plugin", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/mycam/installer.sh | sh"),
                    ("MultiCamAdder", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/MultiCamAdder/installer.sh | sh"),
                    ("Multi-Iptv-Adder", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/MultiIptvAdder/installer.sh | sh"),
                    ("NewVirtualkeyBoard", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/NewVirtualKeyBoard/installer.sh | sh"),
                    ("ONEupdater", "wget -qO- https://raw.githubusercontent.com/Sat-Club/ONEupdaterE2/main/installer.sh | sh"),
                    ("OrangeAudioPlugin", "wget -qO- https://raw.githubusercontent.com/popking159/OrangeAudio/main/installer.sh | sh"),
                    ("Ozeta-Skins-Setup", "wget -qO- https://raw.githubusercontent.com/emil237/skins-enigma2/main/PLUGIN_Skin-ozeta.sh | sh"),
                    ("Plutotv", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/plutotv/plutotv.sh | sh"),
                    ("Quran-karem", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/quran/installer.sh | sh"),
                    ("Quran-karem_v2.2", "wget -qO- https://raw.githubusercontent.com/emil237/quran/main/installer.sh | sh"),
                    ("Radio-80-s", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/Radio-80-s/main/installer.sh | sh"),
                    ("RadioGit", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/radiogit/radiogit.sh | sh"),
                    ("Radio-Stream-Relay", "wget -qO- https://raw.githubusercontent.com/angelheart150/RadioRelay/main/installer.sh | sh"),
                    ("Radiom", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/radiom/radiom.sh | sh"),
                    ("Rakutentv", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/rakutentv/rakutentv.sh | sh"),
                    ("RaedQuickSignal", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/RaedQuickSignal/installer.sh | sh"),
                    ("Rss Reader", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/RSSReader/main/installer.sh | sh"),
                    ("PiconsRename", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/PiconsRename/PiconsRename.sh | sh"),
                    ("pluginmover", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/pluginmover/installer.sh | sh"),
                    ("pluginskinmover", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/pluginskinmover/installer.sh | sh"),
                    ("ScreenNames", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/screennames/screennames.sh | sh"),
                    ("Screen-Recorder", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/screenrecorder/installer.sh | sh"),
                    ("ServiceScanUpdates", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/servicescanupdates/servicescanupdates.sh | sh"),
                    ("SetPicon", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/setpicon/installer.sh | sh"),
                    ("scriptexecuter", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/scriptexecuter/installer.sh | sh"),
                    ("showclock", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/showclock/showclock.sh | sh"),
                    ("Sherlockmod", "wget -qO- https://raw.githubusercontent.com/emil237/sherlockmod/main/installer.sh | sh"),
                    ("Simple-Zoom-Panel", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/simple-zoom-panel/installer.sh | sh"),
                    ("StalkerPortalConverter", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/StalkerPortalConverter/main/installer.sh | sh"),
                    ("SubsSupport_1.5.8-r9", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/SubsSupport/installer1.sh | sh"),
                    ("SubsSupport_by-m.nasr", "wget -qO- https://github.com/popking159/ssupport/raw/main/subssupport-install.sh | sh"),
                    ("SubsSupport_2.1", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/SubsSupport/subssupport_2.1.sh | sh"),
                    ("TheWeather", "wget -qO- https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh | sh"),
                    ("TMBD", "wget -qO- https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh | sh"),
                    ("Tmdb", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/tmdb.sh | sh"),
                    ("TvDream", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/tvDream/main/installer.sh | sh"),
                    ("Transmission", "wget -qO- http://dreambox4u.com/dreamarabia/Transmission_e2/Transmission_e2.sh | sh"),
                    ("TvManager", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/tvManager/main/installer.sh | sh"),
                    ("TvParsa", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/tvParsa/main/installer.sh | sh"),
                    ("TvRaiPreview", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/tvRaiPreview/main/installer.sh | sh"),
                    ("TvSettings", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/tvSettings/main/installer.sh | sh"),
                    ("uninstaller-Plugins", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/unstaller-plugins/installer.sh | sh"),
                    ("vavoo_1.15", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/vavoo/installer.sh | sh"),
                    ("xtraevent_3.3", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/xtraevent_3.3.sh | sh"),
                    ("xtraevent_4.2", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/xtraEvent_4.2.sh | sh"),
                    ("xtraevent_4.5", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/xtraEvent_4.5.sh | sh"),
                    ("Xtraevent_4.6", "wget -qO- https://github.com/emil237/download-plugins/raw/main/Xtraevent-v4.6.sh | sh"),
                    ("xtraevent_6.798", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent_6.798.sh | sh"),
                    ("xtraevent_6.805", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent-6.805.sh | sh"),
                    ("xtraevent_6.820_All-Python", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent-6.820.sh | sh"),
                    ("xtraevent_6.840_PY3", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xtraevent/xtraevent-6.840.sh | sh"),
                    ("WeatherPlugin", "wget -qO- https://raw.githubusercontent.com/fairbird/WeatherPlugin/master/installer.sh | sh"),
                    ("Wireguard-Vpn", "wget -qO- https://raw.githubusercontent.com/m4dhouse/Wireguard-Vpn/python-3.12/WireGuard.sh | sh"),
                    ("WorldCam", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/WorldCam/main/installer.sh | sh"),
                    ("Youtube", "wget -qO- https://raw.githubusercontent.com/fairbird/Youtube-Opensource-DreamOS/master/installer.sh | sh"),
                    ("Zip2Pkg-Converter", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/Zip2Pkg/installer.sh | sh"),
                    ("ZapTimer", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/zaptimer/zaptimer.sh | sh"),
                    ("Zoom_1.1.2-Py3", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/zoom/installer.sh | sh")
                ]
            elif self.section_key == "tools":
                data = [
                    ("Wget", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/wget.sh | sh"),
                    ("Curl", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/curl.sh | sh"),
                    ("Update Enigma2 All Python", "wget -qO- https://raw.githubusercontent.com/emil237/updates-enigma/main/update-all-python.sh | sh"),
                    ("Opkg tools", "wget -qO- http://dreambox4u.com/emilnabil237/script/opkg.sh | sh"),
                    ("Super Script", "wget -qO- https://dreambox4u.com/emilnabil237/script/Super_Script.sh | sh"),
                    ("Delete-password", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/scripts-servise/delete-password.sh | sh"),
                    ("Change-Password-To-root", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/scripts-servise/change-password-to-root.sh | sh"),
                    ("CAM-abertis-astra-sm", "wget -qO- https://dreambox4u.com/emilnabil237/script/CAM-abertis-astra.sh | sh"),
                    ("Epg-Khaled", "wget -qO- https://raw.githubusercontent.com/emilnabil/epg-khaled/main/EPG-khaled.sh | sh"),
                    ("FORMAT_HDD_TO-Ext4", "wget -qO- https://raw.githubusercontent.com/emil237/scripts/main/format-hdd.sh | sh"),
                    ("Repair-Inodes-From-Hdd", "wget -qO- https://raw.githubusercontent.com/emil237/scripts/main/repair-hdd.sh | sh"),
                    ("FIX-ipk-installation", "wget -qO- https://dreambox4u.com/emilnabil237/script/fix-ipk-package-installation.sh | sh"),
                    ("Fix-Xtraevent-Download", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/fix-xtraevent-download.sh | sh"),
                    ("Set_Time_NTP-Google", "wget -qO- https://dreambox4u.com/emilnabil237/script/set_time.sh | sh"),
                    ("Fix Softcam Atv", "wget -qO- http://updates.mynonpublic.com/oea/feed | sh"),
                    ("Fix Softcam OpenPli", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/softcam-support-pli.sh | sh"),
                    ("Wget package Vti", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/tool_vti-wget_1.16.3.sh | sh"),
                    ("UpdateSatellitesOealliance", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/Satellites-Oealliance.sh | sh"),
                    ("UpdateSatellitesOpenPli", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/satellites-openpli.sh | sh"),
                    ("Zip2ipk", "wget -qO- http://dreambox4u.com/emilnabil237/script/zip2ipk.sh | sh")
                ]
            elif self.section_key == "system":
                data = [
                    ("3gmodemmanager", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/3gmodemmanager/3gmodemmanager.sh | sh"),
                    ("Disk_and_CPU_Temperature", "wget -qO- https://raw.githubusercontent.com/emilnabil/dreambox/main/disk_and_cpu_temperature.sh | sh"),
                    ("devicemanager", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/devicemanager.sh | sh"),
                    ("extnumberzap", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/extnumberzap/extnumberzap.sh | sh"),
                    ("mountmanager", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/mountmanager/installer.sh | sh"),
                    ("setpasswd", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/setpasswd.sh | sh"),
                    ("Signalfinder", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/signalfinder.sh | sh"),
                    ("softwaremanager", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/softwaremanager.sh | sh"),
                    ("Ts-Sateditor", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ts-sateditor/ts-sateditor.sh | sh"),
                    ("Xmlupdate", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xmlupdate/xmlupdate.sh | sh")
                ]
            elif self.section_key == "softcams":
                data = [
                    ("Cccam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-cccam.sh | sh"),
                    ("gosatplus-ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-ncam.sh | sh"),
                    ("gosatplus-oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-gosatplus-oscam.sh | sh"),
                    ("gosatplus_v3_arm", "wget -qO- http://e2.gosatplus.com/Plugin/V3/arm-openpli-installer_py3_v3.sh | sh"),
                    ("gosatplus_v3_mips", "wget -qO- http://e2.gosatplus.com/Plugin/V3/mips-openpli-installer_py3_v3.sh | sh"),
                    ("gosatplus_v3_Fix", "wget -qO- http://e2.gosatplus.com/Plugin/V3/GosatPlusPluginFixPy.sh | sh"),
                    ("Hold-flag-ncam", "wget -qO- https://dreambox4u.com/emilnabil237/script/Hold-flag-ncam.sh | sh"),
                    ("Hold-flag-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/script/Hold-flag-Oscam.sh | sh"),
                    ("Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-ncam.sh | sh"),
                    ("Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-oscam.sh | sh"),
                    ("Oscam-11.726-by-lenuxsat", "wget -qO- https://dreambox4u.com/emilnabil237/emu/oscam-by-lenuxsat/installer.sh | sh"),
                    ("oscamicam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-oscamicam.sh | sh"),
                    ("powercam_v2-icam-arm", "wget -qO- https://dreambox4u.com/emilnabil237/emu/powercam/installer.sh | sh"),
                    ("powercam-Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-powercam-ncam.sh | sh"),
                    ("powercam-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-powercam-oscam.sh | sh"),
                    ("Restore-flag-ncam", "wget -qO- https://dreambox4u.com/emilnabil237/script/Restore-flag-ncam.sh | sh"),
                    ("Restore-flag-oscam", "wget -qO- https://dreambox4u.com/emilnabil237/script/Restore-flag-Oscam.sh | sh"),
                    ("Revcam-Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-revcam-ncam.sh | sh"),
                    ("Revcam-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-revcam-oscam.sh | sh"),
                    ("Revcam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-revcam.sh | sh"),
                    ("Supcam-Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-supcam-ncam.sh | sh"),
                    ("Supcam-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-supcam-oscam.sh | sh"),
                    ("Ultracam-Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-ultracam-ncam.sh | sh"),
                    ("Ultracam-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-ultracam-oscam.sh | sh"),
                    ("Ultracam", "wget -qO- https://dreambox4u.com/emilnabil237/emu/installer-ultracam.sh | sh")
                ]
            elif self.section_key == "backup":
                data = [
                    ("Backup-my-Channels", "wget -qO- http://dreambox4u.com/emilnabil237/script/Create-My-backup-shannels.sh | sh"),
                    ("Backup-hotkey", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-hotkey.sh | sh"),
                    ("Backup-network", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-network.sh | sh"),
                    ("Backup-softcams", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-softcams.sh | sh"),
                    ("Backup-tuner", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-tuner.sh | sh"),
                    ("Backup-my-bouquetmakerxtream", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-bouquetmakerxtream.sh | sh"),
                    ("Backup-my-ip2sat-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-ip2sat-server.sh | sh"),
                    ("Backup-my-ipaudio-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-ipaudio-server.sh | sh"),
                    ("Backup-my-ipaudiopro-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-ipaudiopro-server.sh | sh"),
                    ("Backup-my-jediplaylists", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-jediplaylists.sh | sh"),
                    ("Backup-my-multistalkerpro", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-multistalkerpro.sh | sh"),
                    ("Backup-my-Subtitle-Setting", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup_my-subtitle-setting.sh | sh"),
                    ("Backup-my-xstreamity-servers", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-my-xstreamity-servers.sh | sh"),
                    ("Backup-sittings-xtraevent", "wget -qO- http://dreambox4u.com/emilnabil237/script/backup-sittings-xtraevent.sh | sh")
                ]
            elif self.section_key == "restore":
                data = [
                    ("Restore-my-Channels", "wget -qO- http://dreambox4u.com/emilnabil237/script/Restore-My-backup-shannels.sh | sh"),
                    ("Restore-hotkey", "wget -qO- http://dreambox4u.com/emilnabil237/script/resore-hotkey.sh | sh"),
                    ("Restore-network", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-network.sh | sh"),
                    ("Restore-softcams", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-softcams.sh | sh"),
                    ("Restore-tuner", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-tuner.sh | sh"),
                    ("Restore-my-bouquetmakerxtream", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-bouquetmakerxtream.sh | sh"),
                    ("Restore-my-ip2sat-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-ip2sat-server.sh | sh"),
                    ("Restore-my-ipaudio-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-ipaudio-server.sh | sh"),
                    ("Restore-my-ipaudiopro-server", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-ipaudiopro-server.sh | sh"),
                    ("Restore-my-jediplaylists", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-jediplaylists.sh | sh"),
                    ("Restore-my-multistalkerpro", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-multistalkerpro.sh | sh"),
                    ("Restore-My-Subtitle-Setting", "wget -qO- http://dreambox4u.com/emilnabil237/script/Restore_my-subtitle-setting.sh | sh"),
                    ("Restore-my-xstreamity-servers", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-my-xstreamity-servers.sh | sh"),
                    ("Restore-sittings-xtraevent", "wget -qO- http://dreambox4u.com/emilnabil237/script/restore-sittings-xtraevent.sh | sh")
                ]
            elif self.section_key == "images":
                data = [
                    ("BlackHole-3.1.0", "wget -qO- https://dreambox4u.com/emilnabil237/images/BlackHole-3.1.0.sh | sh"),
                    ("Egami-10.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/egami-10.4.sh | sh"),
                    ("Openatv-6.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-6.4.sh | sh"),
                    ("Openatv-7.0", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.0.sh | sh"),
                    ("Openatv-7.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.1.sh | sh"),
                    ("Openatv-7.2", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.2.sh | sh"),
                    ("Openatv-7.3", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.3.sh | sh"),
                    ("Openatv-7.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.4.sh | sh"),
                    ("Openatv-7.5", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.5.sh | sh"),
                    ("Openatv-7.5.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.5.1.sh | sh"),
                    ("Openatv-7.6", "wget -qO- https://dreambox4u.com/emilnabil237/images/openatv-7.6.sh | sh"),
                    ("OpenBlackHole-4.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-4.4-for-vuplus-only.sh | sh"),
                    ("OpenBlackHole-5.0", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.0.sh | sh"),
                    ("OpenBlackHole-5.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.1.sh | sh"),
                    ("OpenBlackHole-5.2", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.2.sh | sh"),
                    ("OpenBlackHole-5.3", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.3.sh | sh"),
                    ("OpenBlackHole-5.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.4.sh | sh"),
                    ("OpenBlackHole-5.5.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/openblackhole-5.5.1.sh | sh"),
                    ("OpenDroid-7.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/opendroid-7.1.sh | sh"),
                    ("Openpli-7.3", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-7.3.sh | sh"),
                    ("OpenPli-8.3", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-8.3.sh | sh"),
                    ("OpenPli-8.3-Time-Shift", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-8.3-py2-TimeShift.sh | sh"),
                    ("OpenPli-9.0-Time-Shift", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-9.0-py3-TimeShift.sh | sh"),
                    ("OpenPli-9.0", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-9.0.sh | sh"),
                    ("OpenPli-9.1", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-9.1.sh | sh"),
                    ("OpenPli-develop", "wget -qO- https://dreambox4u.com/emilnabil237/images/openpli-develop.sh | sh"),
                    ("openspa-7.5.xxx", "wget -qO- https://dreambox4u.com/emilnabil237/images/openspa-7.5.xxx.sh | sh"),
                    ("openspa-8.0.xxx", "wget -qO- https://dreambox4u.com/emilnabil237/images/openspa-8.0.xxx.sh | sh"),
                    ("openspa-8.1.xxx", "wget -qO- https://dreambox4u.com/emilnabil237/images/openspa-8.1.xxx.sh | sh"),
                    ("openspa-8.3.xxx", "wget -qO- https://dreambox4u.com/emilnabil237/images/openspa-8.3.xxx.sh | sh"),
                    ("openspa-8.4.xxx", "wget -qO- https://dreambox4u.com/emilnabil237/images/openspa-8.4.xxx.sh | sh"),
                    ("Openvix-6.6.004", "wget -qO- https://dreambox4u.com/emilnabil237/images/openvix-6.6.004.sh | sh"),
                    ("openvix_latest-version", "wget -qO- https://dreambox4u.com/emilnabil237/images/openvix_latest-version.sh | sh"),
                    ("OpenVision-py2-10.3-r395", "wget -qO- https://dreambox4u.com/emilnabil237/images/openvision/OpenVision-py2-10.3-r395.sh | sh"),
                    ("pure2-6.5", "wget -qO- https://dreambox4u.com/emilnabil237/images/pure2-6.5.sh | sh"),
                    ("pure2-7.3", "wget -qO- https://dreambox4u.com/emilnabil237/images/pure2-7.3.sh | sh"),
                    ("pure2-7.4", "wget -qO- https://dreambox4u.com/emilnabil237/images/pure2-7.4.sh | sh"),
                    ("VTI-15.0.02", "wget -qO- https://dreambox4u.com/emilnabil237/images/vti-15.0.02.sh | sh")
                ]
            elif self.section_key == "media":
                data = [
                    ("BouquetMakerXtream", "wget -qO- http://dreambox4u.com/emilnabil237/plugins/BouquetMakerXtream/installer.sh | sh"),
                    ("E2m3u2Bouquet", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/e2m3u2bouquet/installer.sh | sh"),
                    ("E2Player-MAXBAMBY", "wget -qO- https://gitlab.com/maxbambi/e2iplayer/-/raw/master/install-e2iplayer.sh | sh"),
                    ("E2Player-ZADMARIO", "wget -qO- https://gitlab.com/zadmario/e2iplayer/-/raw/master/install-e2iplayer.sh | sh"),
                    ("IptoSat", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/iptosat/installer.sh | sh"),
                    ("IpAudio 6.7 py2", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ipaudio/installer.sh | sh"),
                    ("IpAudio 7.4 py3", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ipaudio/ipaudio-7.4-ffmpeg.sh | sh"),
                    ("IpAudioPro", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/ipaudiopro/installer.sh | sh"),
                    ("JediEpgExtream", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/jediepgextream/installer.sh | sh"),
                    ("Jedimakerxtream", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/jedimakerxtream/installer.sh | sh"),
                    ("Multistalker", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/multistalker/installer.sh | sh"),
                    ("MultiStalkerPro", "wget -qO- https://raw.githubusercontent.com/emilnabil/multi-stalkerpro/main/installer.sh | sh"),
                    ("Quarter pounder", "wget -qO- http://dreambox4u.com/emilnabil237/script/quarterpounder.sh | sh"),
                    ("Suptv", "wget -qO- https://raw.githubusercontent.com/emil237/suptv/main/installer.sh | sh"),
                    ("YouTube", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/YouTube/installer.sh | sh"),
                    ("xklass-iptv", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xklass/installer.sh | sh"),
                    ("Xtreamty", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/xtreamity/installer.sh | sh"),
                    ("Xcpluginforever", "wget -qO- https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh | sh")
                ]
            elif self.section_key == "feeds":
                data = [
                    ("Eliesat", "wget -qO- https://gitlab.com/eliesat/scripts/-/raw/main/feed/eliesat-feed.sh | sh"),
                    ("Emil", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/FEED-emil-feed.sh | sh"),
                    ("Jungle", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/FEED-jungle-feed.sh | sh"),
                    ("Libraries_3.12.4", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-libraries-3.12.4.sh | sh"),
                    ("Libraries_3.12.6", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-libraries-3.12.sh | sh"),
                    ("Oe-alliance-Picons", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-oe-picons.sh | sh"),
                    ("Oe-alliance-Settings", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-oe-settings.sh | sh"),
                    ("Openatv-Deval", "wget -qO- https://feeds2.mynonpublic.com/devel-feed | sh"),
                    ("OpenPicons", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-openpicons.sh | sh"),
                    ("Softcams-Feed-Openatv", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-OpenAtv-softcam-ALL-Python.sh | sh"),
                    ("OpenDroid-softcam", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-OpenDroid-softcam.sh | sh"),
                    ("OpenEight-softcam", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-OpenEight-softcam.sh | sh"),
                    ("TeamBlue-softcam", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-TeamBlue-softcam.sh | sh"),
                    ("Softcams-Feed-Pure2", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-pure2-softcam.sh | sh"),
                    ("Tarek-Hanfy", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/FEED-Tarek.sh | sh")
                ]
            elif self.section_key == "multiboot":
                data = [
                    ("EgamiBoot 10.5", "wget -qO- https://raw.githubusercontent.com/emil237/egamiboot/main/installer.sh | sh"),
                    ("EgamiBoot 10.6", "wget -qO- https://raw.githubusercontent.com/emil237/egamiboot/main/egamiboot-10.6.sh | sh"),
                    ("Neoboot 9.65", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.65/iNB.sh | sh"),
                    ("Neoboot 9.65 Mod-ElSafty", "wget -qO- https://raw.githubusercontent.com/emil237/neoboot_v9.65/main/iNB_9.65_mod-elsafty.sh | sh"),
                    ("Neoboot 9.60", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.60/iNB.sh | sh"),
                    ("Neoboot 9.58", "wget -qO- https://dreambox4u.com/emilnabil237/plugins/neoboot-v9.58/iNB.sh | sh"),
                    ("Neoboot 9.54", "wget -qO- https://raw.githubusercontent.com/emil237/neoboot_9.54/main/installer.sh | sh"),
                    ("OpenMultiboot 1.3", "wget -qO- https://raw.githubusercontent.com/emil237/openmultiboot/main/installer.sh | sh"),
                    ("OpenMultiboot-E2turk", "wget -qO- https://raw.githubusercontent.com/e2TURK/omb-enhanced/main/install.sh | sh"),
                    ("Multiboot-FlashOnline", "wget -qO- https://raw.githubusercontent.com/emil237/download-plugins/main/multiboot-flashonline.sh | sh")
                ]
            elif self.section_key == "picons":
                data = [
                    ("intelsat_31.5w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/intelsat_31.5w/installer.sh | sh"),
                    ("hispasat_30.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/hispasat_30.0w/installer.sh | sh"),
                    ("intelsat_27.5w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/intelsat_27.5w/installer.sh | sh"),
                    ("intelsat_24.5w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/intelsat_24.5w/installer.sh | sh"),
                    ("ses4_22.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/ses4_22.0w/installer.sh | sh"),
                    ("nss7_20.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/nss7_20.0w/installer.sh | sh"),
                    ("telstar_15.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/telstar_15.0w/installer.sh | sh"),
                    ("express_14w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/express_14w/installer.sh | sh"),
                    ("express_11.0w-14.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/express_11.0w-14.0w/installer.sh | sh"),
                    ("Nilesat_7W-8W", "wget -qO- https://dreambox4u.com/emilnabil237/picons/nilesat/installer.sh | sh"),
                    ("eutelsat_5.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_5.0w/installer.sh | sh"),
                    ("Amos_4.0W", "wget -qO- https://dreambox4u.com/emilnabil237/picons/amos_4.0w/installer.sh | sh"),
                    ("abs_3.0w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/abs_3.0w/installer.sh | sh"),
                    ("thor_0.8w", "wget -qO- https://dreambox4u.com/emilnabil237/picons/thor_0.8w/installer.sh | sh"),
                    ("bulgariasat_1.9e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/bulgariasat_1.9e/installer.sh | sh"),
                    ("eutelsat_3.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_3.0e/installer.sh | sh"),
                    ("astra_4.8e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/astra_4.8e/installer.sh | sh"),
                    ("eutelsat_7.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_7.0e/installer.sh | sh"),
                    ("eutelsat_9.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_9.0e/installer.sh | sh"),
                    ("eutelsat_10.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_10.0e/installer.sh | sh"),
                    ("hotbird_13.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/hotbird_13.0e/installer.sh | sh"),
                    ("eutelsat_16.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_16.0e/installer.sh | sh"),
                    ("astra_19.2e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/astra_19.2e/installer.sh | sh"),
                    ("eutelsat_21.6e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_21.6e/installer.sh | sh"),
                    ("astra_23.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/astra_23.5e/installer.sh | sh"),
                    ("eshail_25.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eshail_25.5e/installer.sh | sh"),
                    ("badr_26.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/badr_26.0e/installer.sh | sh"),
                    ("astra_28.2e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/astra_28.2e/installer.sh | sh"),
                    ("arabsat_30.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/arabsat_30.5e/installer.sh | sh"),
                    ("astra_31.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/astra_31.5e/installer.sh | sh"),
                    ("intelsat_33.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat-intelsat_33.0e/installer.sh | sh"),
                    ("eutelsat_36.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_36.0e/installer.sh | sh"),
                    ("hellas-sat_39.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/hellas-sat_39.0e/installer.sh | sh"),
                    ("turksat_42.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/turksat_42.0e/installer.sh | sh"),
                    ("azerspace_45.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/azerspace_45.0e/installer.sh | sh"),
                    ("azerspace_46.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/azerspace_46.0e/installer.sh | sh"),
                    ("turksat_50.0e_56.0e_57e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/turksat_50.0e_56.0e_57e/installer.sh | sh"),
                    ("belintersat_51.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/belintersat_51.5e/installer.sh | sh"),
                    ("turkmenalem_52.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/turkmenalem_52.0e/installer.sh | sh"),
                    ("alyahsat_52.5e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/alyahsat_52.5e/installer.sh | sh"),
                    ("express_53.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/express_53.0e/installer.sh | sh"),
                    ("yamal_54.9e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/gsat-yamal_54.9e/installer.sh | sh"),
                    ("intelsat_60.0e_66.0e_68.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/intelsat_60.0e_66.0e_68.0e/installer.sh | sh"),
                    ("intelsat_62.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/intelsat_62.0e/installer.sh | sh"),
                    ("eutelsat_70.0e_74.9e_75.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/eutelsat_70.0e_74.9e_75.0e/installer.sh | sh"),
                    ("Intelsat_72.1e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/Intelsat_72.1e/installer.sh | sh"),
                    ("abs_75.0e", "wget -qO- https://dreambox4u.com/emilnabil237/picons/abs_75.0e/installer.sh | sh"),
                    ("picons-other", "wget -qO- https://raw.githubusercontent.com/emil237/picon-other/main/installer.sh | sh"),
                    ("Chocholousek-Picons", "wget -qO- https://github.com/s3n0/e2plugins/raw/master/ChocholousekPicons/online-setup | sh")
                ]
            elif self.section_key == "bootlogos":
                data = [
                    ("BootlogoSwapper Atv", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-Atv.sh | sh"),
                    ("Bootlogo-PURE2", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootLogoswapper-Pure2.sh | sh"),
                    ("BootlogoSwapper Christmas", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-christmas.sh | sh"),
                    ("BootlogoSwapper Pli", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-pli.sh | sh"),
                    ("BootlogoSwapper OpenBH", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-OpenBH.sh | sh"),
                    ("BootlogoSwapper Egami", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootLogoswapper-Egami.sh | sh"),
                    ("BootlogoSwapper OpenVix", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-OpenVix.sh | sh"),
                    ("BootlogoSwapper Kids", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswapper-kids.sh | sh"),
                    ("BootlogoSwapper Ramadan", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogo-swapper-ramadan.sh | sh"),
                    ("BootlogoSwapper Eid-Aldha", "wget -qO- http://dreambox4u.com/emilnabil237/script/bootlogoswaper-Eid-Aldha.sh | sh"),
                    ("BootlogoSwapper V2.1", "wget -qO- http://dreambox4u.com/emilnabil237/script/BootlogoSwapper_v2.1.sh | sh"),
                    ("BootlogoSwapper V2.3", "wget -qO- http://dreambox4u.com/emilnabil237/script/BootlogoSwapper_v2.3.sh | sh")
                ]
            elif self.section_key == "remove":
                data = [
                    ("Remove all_Crashlogs", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL_all_Crashlogs.sh | sh"),
                    ("Remove CCcamFinder", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-CCcamFinder.sh | sh"),
                    ("Remove-Channels", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-channels.sh | sh"),
                    ("Remove-E2iplayer", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-e2iplayer.sh | sh"),
                    ("Remove-Emu-All", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-emus.sh | sh"),
                    ("Remove-Emu-Ncam", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/del-emu-ncam.sh | sh"),
                    ("Remove-Emu-Oscam", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/del-emu-oscam.sh | sh"),
                    ("Remove-Emus-Config-Files", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-emus-config-files.sh | sh"),
                    ("Remove-Jedimaker-playlists", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/del-Jedimaker-playlists.sh | sh"),
                    ("Remove-Plugin-mediaplayer2", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-mediaplayer2.sh | sh"),
                    ("Remove-Plugin-NetSpeedTest", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-NetSpeedTest.sh | sh"),
                    ("Remove-Plugin-OscamFinder", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-OscamFinder.sh | sh"),
                    ("Remove-Plugin-alternativesoftcammanager", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-alternativesoftcammanager.sh | sh"),
                    ("Remove-Plugin-Plugin-FreeServer", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-Plugin-FreeServer.sh | sh"),
                    ("Remove-Plugin-levi45-addonsmanager", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-levi45-addonsmanager.sh | sh"),
                    ("Remove-Plugin-m3u-converter", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-m3u-converter.sh | sh"),
                    ("Remove-Plugin-SatVenusPANEL", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-SatVenusPANEL.sh | sh"),
                    ("Remove-Plugin-tvpanel", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-tvpanel.sh | sh"),
                    ("Remove-Plugin-XCplugin", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-Plugin-XCplugin.sh | sh"),
                    ("Remove-Plugin-Xstreamity", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-xstreamity.sh | sh"),
                    ("Remove-Plugin-youtube", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-plugin-youtube.sh | sh"),
                    ("Remove-Plugin-SoftCam_Manager", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-SoftCam_Manager.sh | sh"),
                    ("Remove-Plugin-Subssupport", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-subssupport.sh | sh"),
                    ("Remove-Plugin-Tvpanel", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/DEL-tvpanel.sh | sh"),
                    ("Remove-Tuner-Settings", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/del-Tuner-Settings.sh | sh"),
                    ("Remove-Xstreamity-playlists", "wget -qO- https://dreambox4u.com/emilnabil237/script/remove/del-Xstreamity-playlists.sh | sh")
                ]
            elif self.section_key == "other_channels":
                data = [
                    ("Emil Nabil", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-emil-nabil/main/installer.sh | sh"),
                    ("Ahmed Romeh", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-romeh/main/installer.sh | sh"),
                    ("Hazem-Wahba", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-hazem-wahba/main/installer.sh | sh"),
                    ("Khaled Ali", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-khaled/main/installer.sh | sh"),
                    ("Mohamed Goda", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-mohamed-goda/main/installer.sh | sh"),
                    ("Mohamed-Nasr", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-mnasr/main/installer.sh | sh"),
                    ("Tarek Ashry", "wget -qO- https://raw.githubusercontent.com/emilnabil/channel-tarek-ashry/main/installer.sh | sh"),
                    ("Elsafty-Tv-Radio-Steaming", "wget -qO- https://dreambox4u.com/emilnabil237/settings/elsafty/installer.sh | sh"),
                    ("Tuner_Backup_By-Emil-Nabil", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/restore-tuner-emil.sh | sh"),
                    ("Tuner_Backup_By-M-Goda", "wget -qO- https://github.com/emilnabil/download-plugins/raw/main/restore-tuner-goda.sh | sh")
                ]
            elif self.section_key == "ciefp_channels":
                data = [
                    ("ciefp-channels-e2-75e-34w", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-channels-e2-75e-34w.sh | sh"),
                    ("1sat-19E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-1sat-19E.sh | sh"),
                    ("2satA-19E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-2satA-19E-13E.sh | sh"),
                    ("2satB-19E-16E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-2satB-19E-16E.sh | sh"),
                    ("3satA-9E-10E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-3satA-9E-10E-13E.sh | sh"),
                    ("3satB-19E-16E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-3satB-19E-16E-13E.sh | sh"),
                    ("4satA-28E-19E-13E-30W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-4satA-28E-19E-13E-30W.sh | sh"),
                    ("4satB-19E-16E-13E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-4satB-19E-16E-13E-0.8W.sh | sh"),
                    ("5sat-19E-16E-13E-1.9E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-5sat-19E-16E-13E-1.9E-0.8W.sh | sh"),
                    ("6sat-23E-19E-16E-13E-1.9E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-6sat-23E-19E-16E-13E-1.9E-0.8W.sh | sh"),
                    ("7sat-23E-19E-16E-13E-4.8E-1.9E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-7sat-23E-19E-16E-13E-4.8E-1.9E-0.8W.sh | sh"),
                    ("8sat-28E-23E-19E-16E-13E-4.8E-1.9E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-8sat-28E-23E-19E-16E-13E-4.8E-1.9E-0.8W.sh | sh"),
                    ("9sat-28E-23E-19E-16E-13E-9E-1.9E-0.8W-5W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-9sat-28E-23E-19E-16E-13E-9E-1.9E-0.8W-5W.sh | sh"),
                    ("10sat-39E-28E-23E-19E-16E-13E-9E-4.8E-1.9E-0.8W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-10sat.sh | sh"),
                    ("13sat-42E-39E-28E-23E-19E-16E-13E-9E-7E-4.8E-1.9E-0.8w-5w", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-13sat.sh | sh"),
                    ("16sat-42E-39E-28E-26E-23E-19E-16E-13E-10E-9E-7E-4.8E-1.9E-0.8w-4W-5w", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-16sat.sh | sh"),
                    ("18sat-42E-39E-36E-33E-28E-26E-23E-19E-16E-13E-10E-9E-7E-4.8E-1.9E-0.8w-4w-5w", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/ciefp-channels-e2/ciefp-E2-18sat.sh | sh")
                ]
            elif self.section_key == "morph883_channels":
                data = [
                    ("Morph883_0.8W-4.8E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_0.8W-4.8E-13E.sh | sh"),
                    ("Morph883_0.8W-13E-19.2E-28.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_0.8W-13E-19.2E-28.2E.sh | sh"),
                    ("Morph883_0.8W-13E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_0.8W-13E-19.2E.sh | sh"),
                    ("Morph883_0.8W-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_0.8W-13E.sh | sh"),
                    ("Morph883_4.8E-13E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_4.8E-13E-19.2E.sh | sh"),
                    ("Morph883_4.8E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_4.8E-13E.sh | sh"),
                    ("Morph883_9E-13E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_9E-13E-19.2E.sh | sh"),
                    ("Morph883_9E-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_9E-13E.sh | sh"),
                    ("Morph883_13E-16E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-16E-19.2E.sh | sh"),
                    ("Morph883_13E-16E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-16E.sh | sh"),
                    ("Morph883_13E-19.2E-23.5E-28.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-19.2E-23.5E-28.2E.sh | sh"),
                    ("Morph883_13E-19.2E-23.5E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-19.2E-23.5E.sh | sh"),
                    ("Morph883_13E-19.2E-28.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-19.2E-28.2E.sh | sh"),
                    ("Morph883_13E-19.2E-42E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-19.2E-42E.sh | sh"),
                    ("Morph883_13E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-19.2E.sh | sh"),
                    ("Morph883_13E-23.5E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-23.5E.sh | sh"),
                    ("Morph883_13E-28.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-28.2E.sh | sh"),
                    ("Morph883_13E-42E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E-42E.sh | sh"),
                    ("Morph883_13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_13E.sh | sh"),
                    ("Morph883_30W-13E-19.2E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_30W-13E-19.2E.sh | sh"),
                    ("Morph883_30W-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_30W-13E.sh | sh"),
                    ("Morph883_Motor", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_Motor.sh | sh"),
                    ("Morph883_Settings", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/morpheus883-channels/E2_Morph883_Settings.sh | sh")
                ]
            elif self.section_key == "vaninbal_channels":
                data = [
                    ("Vhannibal-Dual-13-19E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-13-19E.sh | sh"),
                    ("Vhannibal-Dual-DTT-Campania", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-DTT-Campania.sh | sh"),
                    ("Vhannibal-Dual-DTT-Italia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-DTT-Italia.sh | sh"),
                    ("Vhannibal-Dual-DTT-Lazio", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-DTT-Lazio.sh | sh"),
                    ("Vhannibal-Dual-DTT-Lombardia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-DTT-Lombardia.sh | sh"),
                    ("Vhannibal-Dual-DTT-Piemonte", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Dual-DTT-Piemonte.sh | sh"),
                    ("Vhannibal-HotBird-13E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-13E.sh | sh"),
                    ("Vhannibal-HotBird-DTT-Campania", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-DTT-Campania.sh | sh"),
                    ("Vhannibal-HotBird-DTT-Italia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-DTT-Italia.sh | sh"),
                    ("Vhannibal-HotBird-DTT-Lazio", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-DTT-Lazio.sh | sh"),
                    ("Vhannibal-HotBird-DTT-Lombardia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-DTT-Lombardia.sh | sh"),
                    ("Vhannibal-HotBird-DTT-Piemonte", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-HotBird-DTT-Piemonte.sh | sh"),
                    ("Vhannibal-Motor-70E-45W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-70E-45W.sh | sh"),
                    ("Vhannibal-Motor-DTT-Campania", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Campania.sh | sh"),
                    ("Vhannibal-Motor-DTT-Italia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Italia.sh | sh"),
                    ("Vhannibal-Motor-DTT-Lazio", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Lazio.sh | sh"),
                    ("Vhannibal-Motor-DTT-Lombardia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Lombardia.sh | sh"),
                    ("Vhannibal-Motor-DTT-Piemonte", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Piemonte.sh | sh"),
                    ("Vhannibal-Motor-DTT-Romagna", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Romagna.sh | sh"),
                    ("Vhannibal-Motor-DTT-Sardegna", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Sardegna.sh | sh"),
                    ("Vhannibal-Motor-DTT-Sicilia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Motor-DTT-Sicilia.sh | sh"),
                    ("Vhannibal-Quadri-9-13-16-19-23E", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Quadri-9-13-16-19-23E.sh | sh"),
                    ("Vhannibal-Quadri-13-19-5E-1W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Quadri-13-19-5E-1W.sh | sh"),
                    ("Vhannibal-Quadri-13-19-9E-5W", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Quadri-13-19-9E-5W.sh | sh"),
                    ("Vhannibal-Quadri-DTT-Italia", "wget -qO- https://raw.githubusercontent.com/emilnabil/download-plugins/main/vanenbal-channels/Vhannibal-Quadri-DTT-Italia.sh | sh")
                ]
            elif self.section_key == "openatv_skins":
                data = [
                    ("Aglare-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh"),
                    ("Areadeltasat_fhd", "wget https://github.com/emil237/skins-enigma2/raw/refs/heads/main/ATV/skins_areadeltasat_fhd_dragon_1_9_Poster_Backdrop.sh -O - | /bin/sh"),
                    ("Barby-Black-py3-FHD", "wget https://dreambox4u.com/emilnabil237/script/SKIN-Barby-Black-py3-fhd.sh -O - | /bin/sh"),
                    ("Barby-Green-py3-FHD", "wget https://dreambox4u.com/emilnabil237/script/SKIN-Barby-Green-py3-FHD.sh -O - | /bin/sh"),
                    ("Barby-purple-py3-FHD", "wget https://dreambox4u.com/emilnabil237/script/SKIN-Barby-purple-py3-fhd.sh -O - | /bin/sh"),
                    ("Barby-py3-FHD", "wget https://dreambox4u.com/emilnabil237/script/SKIN-Barby-py3-fhd.sh -O - | /bin/sh"),
                    ("Fury-FHD", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
                    ("Gradient-fhd", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/skins-gradient-fhd.sh -O - | /bin/sh"),
                    ("Maxy-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/maxyatv/installer.sh -O - | /bin/sh"),
                    ("Full HD Glass17", "wget http://dreambox4u.com/emilnabil237/skins/skin-fullhdglass17/installer.sh -O - | /bin/sh"),
                    ("MyMetrixLiteBackup", "wget https://raw.githubusercontent.com/emilnabil/download-plugins/refs/heads/main/MyMetrixLiteBackup.sh -O - | /bin/sh"),
                    ("MetrixFHD-Extraevent-PosterXD", "wget https://dreambox4u.com/emilnabil237/skins/openatv/SKIN-MetrixFHD-OpenATV-Extraevent-PosterX.sh -O - | /bin/sh"),
                    ("malek-fhd", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/ATV/skins-malek-fhd_2.2_py3.11.2-py3.12.1.sh -O - | /bin/sh"),
                    ("Nacht_1.7.3", "wget http://dreambox4u.com/emilnabil237/script/SKIN-ATV-nacht_1.7.3.sh -O - | /bin/sh"),
                    ("Op-Artkoala-FHD", "wget https://dreambox4u.com/emilnabil237/skins/openatv/skins-op-artkoala.sh -O - | /bin/sh"),
                    ("Ozeta-Xtra", "wget http://dreambox4u.com/emilnabil237/script/SKIN-ATV-ozeta-xtra.sh -O - | /bin/sh"),
                    ("XDreamy-FHD", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh")
                ]
            elif self.section_key == "TeamNitro_skins":
                data = [
                    ("TeamNitro Control", "wget https://gitlab.com/emilnabil1/teamnitro/-/raw/main/SKIN-teamnitro.sh -O - | /bin/sh"),
                    ("AlAyam-FHD", "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerAL.sh -O - | /bin/sh"),
                    ("Desert-FHD", "wget https://gitlab.com/emilnabil1/teamnitro/-/raw/main/installer-skin-desert.sh -O - | /bin/sh"),
                    ("BoHLALA-FHD", "wget https://gitlab.com/emilnabil1/teamnitro/-/raw/main/installer.sh -O - | /bin/sh"),
                    ("Dragon-FHD", "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerD.sh -O - | /bin/sh"),
                    ("NitroAdvance-FHD", "wget https://raw.githubusercontent.com/biko-73/TeamNitro/main/script/installerN.sh -O - | /bin/sh"),
                    ("Klll-Pro-FHD", "wget https://raw.githubusercontent.com/biko-73/zelda77/main/installer.sh -O - | /bin/sh")
                ]
            elif self.section_key == "OpenBH_skins":
                data = [
                    ("Aglare-fhd", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglarepli/installer.sh -O - | /bin/sh"),
                    ("Fury-FHD", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
                    ("MX_BlackSea", "wget https://dreambox4u.com/emilnabil237/skins/obh/skins-MX_BlackSea.sh -O - | /bin/sh"),
                    ("MX-Sline-Black-Red-Gradient", "wget https://dreambox4u.com/emilnabil237/skins/obh/mx-sline-black-red-gradient_py3.12.sh -O - | /bin/sh"),
                    ("MX_Sline-Blue", "wget https://dreambox4u.com/emilnabil237/skins/obh/MX_Sline-Blue_OBH_5.4_py3.12_py3.12.sh -O - | /bin/sh"),
                    ("Mx-Sline-Glass-Gradient", "wget https://github.com/emilnabil/skins-obh/raw/refs/heads/main/skins-mx-sline-glass-gradient.sh -O - | /bin/sh"),
                    ("MX_Sline-Red_X2", "wget https://dreambox4u.com/emilnabil237/skins/obh/MX_Sline-Red_X2_py3.12.sh -O - | /bin/sh"),
                    ("OpenBhGreenFHD", "wget https://dreambox4u.com/emilnabil237/skins/obh/skin_OpenBhGreenFHD.sh -O - | /bin/sh"),
                    ("XDreamy-FHD", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
                    ("Youchie-OBH-FHD", "wget https://raw.githubusercontent.com/emilnabil/skins-obh/refs/heads/main/skin-Youchie-OBH-FHD.sh -O - | /bin/sh")
                ]
            elif self.section_key == "Egami_skins":
                data = [
                    ("Aglare-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh"),
                    ("Fury-FHD", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
                    ("Premium-Fhd", "wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium-fhd-py3.sh -O - | /bin/sh"),
                    ("Premium-Black-Fhd", "wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium--black-fhd-py3.sh -O - | /bin/sh"),
                    ("Premium-Blue-Fhd", "wget https://dreambox4u.com/emilnabil237/skins/script/SKIN-egami-premium--blue-fhd-py3.sh -O - | /bin/sh"),
                    ("XDreamy-FHD", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh")
                ]
            elif self.section_key == "OpenPli_py3_skins":
                data = [
                    ("Aglare-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglarepli/installer.sh -O - | /bin/sh"),
                    ("BARDO-FHD", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/refs/heads/main/pli/Skin-bardo-fhd_3.7.2.sh -O - | /bin/sh"),
                    ("BLACKNEON-XP_Mod_M-Nasr", "wget https://dreambox4u.com/emilnabil237/skins/pli9x/Skin-BLACKNEON-XP_mod_mnasr-pli9x.sh -O - | /bin/sh"),
                    ("malek-fhd", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/Skin-malek-fhd_1.2.sh -O - | /bin/sh"),
                    ("Ozeta-Xtra", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-ozeta-xtra.sh -O - | /bin/sh"),
                    ("XDreamy-FHD", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
                    ("Youchie-PLI-FHD", "wget https://raw.githubusercontent.com/emilnabil/skins-openpli-9x/refs/heads/main/skin-Youchie-PLI-FHD.sh -O - | /bin/sh")
                ]
            elif self.section_key == "OpenSpa_skins":
                data = [
                    ("Aglare-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglareatv/installer.sh -O - | /bin/sh"),
                    ("Fury-FHD", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
                    ("estuary-1080-FHD", "wget https://gitlab.com/elbrins/skins/-/raw/main/Spa/Skin-estuary-1080.sh -O - | /bin/sh"),
                    ("Skyline", "wget https://github.com/emilnabil/skins-spa/raw/refs/heads/main/skin-Skyline.sh -O - | /bin/sh")
                ]
            elif self.section_key == "OpenVix_skins":
                data = [
                    ("Aglare-FHD", "wget https://raw.githubusercontent.com/popking159/skins/refs/heads/main/aglarepli/installer.sh -O - | /bin/sh"),
                    ("E2-darkos-FHD", "wget https://dreambox4u.com/emilnabil237/skins/openvix/skins-e2-darkos.sh -O - | /bin/sh"),
                    ("Fury-FHD", "wget https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh"),
                    ("Magic-FHD", "wget https://dreambox4u.com/emilnabil237/skins/openvix/skins-openvix-magic-fhd.sh -O - | /bin/sh"),
                    ("Vixbmc-1080-Confluence-FHD", "wget https://dreambox4u.com/emilnabil237/skins/openvix/skins-openvix-vixbmc-1080-confluence.sh -O - | /bin/sh"),
                    ("XDreamy-FHD", "wget https://raw.githubusercontent.com/Insprion80/Skins/main/xDreamy/installer.sh -O - | /bin/sh"),
                    ("Youchie-OpenVix-FHD", "wget https://raw.githubusercontent.com/emilnabil/skins-obh/refs/heads/main/skin-Youchie-OBH-FHD.sh -O - | /bin/sh")
                ]
            elif self.section_key == "OpenPli_py2_skins":
                data = [
                    ("Bluemetal-FHD", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/refs/heads/main/pli/Skin-bluemetal-fhd.sh -O - | /bin/sh"),
                    ("CH.LEAGUE-FHD", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-CH.LEAGUE-FHD.sh -O - | /bin/sh"),
                    ("Maxy-FHD", "wget https://dreambox4u.com/emilnabil237/skins/script/skins-Maxy-FHD.sh -O - | /bin/sh"),
                    ("Ozeta-Xtra", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-ozeta-xtra.sh -O - | /bin/sh"),
                    ("QATAR-2022-V3-FHD", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-QATAR-2022-V3-FHD.sh -O - | /bin/sh"),
                    ("SPIDERMAN-FHD", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-SPIDERMAN-FHD.sh -O - | /bin/sh"),
                    ("WAR-S-FHD", "wget http://dreambox4u.com/emilnabil237/script/SKIN-PLI-WAR-S-FHD.sh -O - | /bin/sh"),
                    ("BLACKSKY-S-HD", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-BLACKSKY-S-HD-MOD-By-Muaath.sh -O - | /bin/sh"),
                    ("BATMAN-MP-HD", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-BATMAN-MP-HD-By-Muaath.sh -O - | /bin/sh"),
                    ("TOKYO2020-FHD", "wget https://raw.githubusercontent.com/emil237/skins-enigma2/main/pli/SKIN-TOKYO2020-FHD-By-Muaath.sh -O - | /bin/sh")
                ]
            elif self.section_key == "PluginXtreamity_skins":
                data = [
                    ("Abstract", "wget https://dreambox4u.com/emilnabil237/plugins/xtreamity/installer-skin-abstract.sh -O - | /bin/sh"),
                    ("qatar2022", "wget https://dreambox4u.com/emilnabil237/plugins/xtreamity/installer-skin-qatar.sh -O - | /bin/sh"),
                    ("Toys", "wget https://dreambox4u.com/emilnabil237/plugins/xtreamity/installer-skin-toys.sh -O - | /bin/sh")
                ]
                
            safe = []
            for name, cmd in data:
                safe.append({
                    "name": name, 
                    "cmd": cmd, 
                    "selected": False, 
                    "installed": False
                })
                
            self._items = safe
            self._repaint()
            self._update_green_label()
        except Exception as e:
            self.session.open(MessageBox, "Error loading list: %s" % str(e), MessageBox.TYPE_ERROR, timeout=3)

    def _current_index(self):
        try:
            return self["list"].getSelectedIndex()
        except Exception:
            return -1

    def toggle_current(self):
        idx = self._current_index()
        if idx < 0 or idx >= len(self._items):
            return
        self._items[idx]["selected"] = not self._items[idx].get("selected")
        self._repaint()
        self["list"].moveToIndex(idx)
        self._update_green_label()

    def toggle_select_all(self):
        if not self._items:
            return
        any_unselected = any(not x.get("selected") for x in self._items)
        for x in self._items:
            x["selected"] = any_unselected
        self._repaint()
        self._update_green_label()

    def install_selected(self):
        sel = [x for x in self._items if x.get("selected")]
        if not sel:
            idx = self._current_index()
            if idx < 0 or idx >= len(self._items):
                return
            sel = [ self._items[idx] ]

        cmdlist_b = []
        for x in sel:
            cmd = x.get("cmd", "")
            cmdlist_b.append(cmd)

        if not cmdlist_b:
            return

        title = "%s - installing %d item(s)" % (self.title, len(cmdlist_b))

        for item in self._items:
            for s in sel:
                if item.get("name") == s.get("name") and item.get("cmd") == s.get("cmd"):
                    item["selected"] = False
        
        self._repaint()
        self._update_green_label()
        self.session.open(Console, title, cmdlist_b)

    def doRefresh(self):
        self._load_and_fill()
        self.session.open(MessageBox, "List refreshed.", MessageBox.TYPE_INFO, timeout=3)

    def restartEnigma2(self):
        restart_commands = [
            "systemctl restart enigma2",
            "killall -9 enigma2"
        ]
        self.session.open(
            Console, 
            "Restarting Enigma2", 
            restart_commands
        )

def main(session, **kwargs):
    session.open(EmilPanelProScreen)

def menu_main(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("Emil Panel Pro", main, "emilpanelpro", 45)]
    return []

def Plugins(path=None, **kwargs):
    list = []
    list.append(PluginDescriptor(
        name="Emil Panel Pro",
        description=PLUGIN_DESC,
        where=PluginDescriptor.WHERE_PLUGINMENU,
        icon=os.path.join(plugin_path, "EmilPanel.png"),
        fnc=main
    ))
    list.append(PluginDescriptor(
        name="Emil Panel Pro",
        description=PLUGIN_DESC,
        where=PluginDescriptor.WHERE_MENU,
        fnc=menu_main
    ))
    return list